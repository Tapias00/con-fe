DROP DATABASE IF EXISTS pd_daniel_tapias_ritchie;
CREATE DATABASE pd_daniel_tapias_ritchie CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE pd_daniel_tapias_ritchie;

DROP TABLE IF EXISTS `transaction`;
DROP TABLE IF EXISTS `invoice`;
DROP TABLE IF EXISTS `customer`;
DROP TABLE IF EXISTS `platform`;

CREATE TABLE `platform` (
  `platform_id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE `customer` (
  `customer_id` INT AUTO_INCREMENT PRIMARY KEY,
  `national_id` BIGINT NOT NULL UNIQUE,
  `full_name` VARCHAR(200) NOT NULL,
  `address` VARCHAR(300),
  `phone` VARCHAR(50),
  `email` VARCHAR(200),
  CONSTRAINT `email_format_chk` CHECK (INSTR(`email`, '@') > 1)
);

CREATE TABLE `invoice` (
  `invoice_id` INT AUTO_INCREMENT PRIMARY KEY,
  `invoice_number` VARCHAR(50) NOT NULL UNIQUE,
  `billing_period` VARCHAR(50) NOT NULL,
  `amount_billed` DECIMAL(14,2) NOT NULL CHECK (`amount_billed` >= 0),
  `customer_id` INT NOT NULL,
  CONSTRAINT `fk_invoice_customer` FOREIGN KEY (`customer_id`) REFERENCES `customer`(`customer_id`) ON DELETE RESTRICT
);

CREATE TABLE `transaction` (
  `transaction_id` INT AUTO_INCREMENT PRIMARY KEY,
  `transaction_code` VARCHAR(100) NOT NULL UNIQUE,
  `occurred_at` DATETIME NOT NULL,
  `amount` DECIMAL(14,2) NOT NULL CHECK (`amount` >= 0),
  `status` VARCHAR(50) NOT NULL,
  `type` VARCHAR(50) NOT NULL,
  `platform_id` INT NOT NULL,
  `invoice_id` INT NOT NULL,
  `customer_id` INT NOT NULL,
  CONSTRAINT `fk_tx_platform` FOREIGN KEY (`platform_id`) REFERENCES `platform`(`platform_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_tx_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoice`(`invoice_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_tx_customer` FOREIGN KEY (`customer_id`) REFERENCES `customer`(`customer_id`) ON DELETE RESTRICT
);

CREATE INDEX `idx_transaction_invoice` ON `transaction`(`invoice_id`);
CREATE INDEX `idx_transaction_customer` ON `transaction`(`customer_id`);
CREATE INDEX `idx_transaction_platform` ON `transaction`(`platform_id`);
