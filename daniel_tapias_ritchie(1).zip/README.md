# Proyecto SQL — MySQL ONLY (Daniel Tapias · Clan Ritchie)

> **Objetivo:** aprender a diseñar una base de datos **normalizada**, cargar datos desde **CSV**, exponer un **CRUD** con **Express (Node.js)** y practicar **consultas con relaciones**.

**Base de datos:** `pd_daniel_tapias_ritchie` (MySQL 8).  
**Backend:** `backend-mysql/` (puerto 3001).  
**UI mínima:** `frontend/index.html` (sirve estático desde el backend).

---

## 1) ¿Qué problema resolvemos?
Tenemos un Excel con transacciones (pagos) que mezcla información de clientes, facturas, plataformas y transacciones. Eso genera **redundancias** y **errores**. La solución es normalizar los datos en **tablas relacionadas**.

### 1.1 Normalización (1FN → 3FN) — MER/ERD
Separé los datos en 4 entidades:

- **platform**(platform_id, name)  
- **customer**(customer_id, national_id, full_name, address, phone, email)  
- **invoice**(invoice_id, invoice_number, billing_period, amount_billed, customer_id)  
- **transaction**(transaction_id, transaction_code, occurred_at, amount, status, type, platform_id, invoice_id, customer_id)

**Justificación resumida:**
- **1FN**: todos los valores son atómicos (sin listas dentro de una celda).  
- **2FN**: cada atributo depende por completo de la clave primaria de su tabla.  
- **3FN**: eliminamos dependencias transitivas (por ejemplo, el nombre de la plataforma no se guarda repetido en `transaction` sino como FK a `platform`).

> Si en tu negocio **una transacción paga varias facturas**, crea una tabla puente:  
> `payment(transaction_id, invoice_id, amount)` y quita `invoice_id` de `transaction`.

Revisa `erd.png` para ver el modelo.

---

## 2) Estructura del proyecto
```
project/
├─ sql/
│  └─ mysql_schema.sql          # DDL (MySQL 8)
├─ data/
│  ├─ platforms.csv
│  ├─ customers.csv
│  ├─ invoices.csv
│  └─ transactions.csv          # CSV normalizados (salieron del Excel)
├─ backend-mysql/
│  ├─ .env.sample               # variables de entorno (cópialas a .env)
│  ├─ package.json
│  ├─ index.js                  # API Express (CRUD + analytics)
│  └─ load_csv.js               # carga masiva CSV → MySQL
├─ frontend/
│  └─ index.html                # dashboard mínimo (CRUD de customer)
├─ postman_collection.json      # requests listos (puerto 3001)
├─ erd.png                      # diagrama
└─ README.md                    # este archivo
```

---

## 3) Pasos para ejecutarlo (principiante)
### 3.1 Crear BD y tablas (MySQL 8)
```bash
mysql -u root -p < sql/mysql_schema.sql
```

### 3.2 Levantar el backend
```bash
cd backend-mysql
cp .env.sample .env     # edita si tu usuario/clave difiere
npm install
npm run start           # http://localhost:3001
```

### 3.3 Cargar datos desde CSV (carga masiva)
```bash
cd backend-mysql
node load_csv.js
```
> El script usa **inserciones con UPSERT** (ON DUPLICATE KEY UPDATE) para que sea **idempotente** (lo puedes correr varias veces sin duplicar).

### 3.4 Probar desde el navegador
Abre `http://localhost:3001` para usar el dashboard de **Customers** (crear, editar, eliminar).

### 3.5 Probar con Postman
Importa `postman_collection.json`. Incluye:
- `GET /api/health`
- `GET /api/customers`, `POST /api/customers`, `PUT /api/customers/:id`, `DELETE /api/customers/:id`
- `GET /api/analytics/total-paid-by-customer`
- `GET /api/analytics/pending-invoices`
- `GET /api/analytics/transactions-by-platform?platform=Nequi`

---

## 4) Validaciones, seguridad y consistencia
- **Integridad referencial**: FKs entre `transaction` → (`platform`, `invoice`, `customer`) y `invoice` → `customer`.
- **Unicidad**: `platform.name`, `customer.national_id`, `invoice.invoice_number`, `transaction.transaction_code`.
- **Checks**: `amount_billed >= 0`, `amount >= 0`, `email` con `@` (CHECK básico; además se valida en API).
- **SQL Injection**: el backend usa **consultas preparadas** (mysql2/promise).
- **Datos idempotentes**: carga CSV con UPSERT.
- **Índices**: en transacciones por `invoice_id`, `customer_id`, `platform_id` para acelerar consultas analíticas.

> **Tip**: MySQL 8 ya **evalúa** CHECK constraints. Aun así, valida también en la API para feedback inmediato al usuario.

---

## 5) CRUD (relaciones y validaciones)
- **Customers**: CRUD completo con validaciones de formato y campos obligatorios.
- **Invoices**: CRUD con validación de `customer_id` existente y `amount_billed >= 0`.
- **Transactions**: CRUD con validación de FKs (`platform_id`, `invoice_id`, `customer_id`), `amount >= 0`, y `occurred_at` requerido (`YYYY-MM-DD HH:MM:SS`).

El manejo de relaciones se evidencia en las FKs y reglas de la base de datos más las validaciones cruzadas en los controladores.

---

## 6) Optimización y consistencia (criterios de la rúbrica)
- **Índices**: en `transaction` por `invoice_id`, `customer_id`, `platform_id`.
- **Restricciones**: FKs, UNIQUE y CHECK para garantizar integridad.
- **Seguridad**: consultas preparadas; variables en `.env`.
- **Carga masiva**: `load_csv.js` con UPSERT (idempotente).

---

## 7) Ejecución rápida (resumen)
1) `mysql -u root -p < sql/mysql_schema.sql`
2) `cd backend-mysql && cp .env.sample .env && npm install && npm run start`
3) `cd backend-mysql && node load_csv.js`
4) UI: `http://localhost:3001` — API en `/api/*`

*Actualizado el 2025-08-12.*
