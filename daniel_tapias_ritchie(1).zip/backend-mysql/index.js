
/**
 * API MySQL — CRUD + Analytics
 * - Base de datos: pd_daniel_tapias_ritchie (ver sql/mysql_schema.sql)
 * - Validaciones: email básico, presencia de campos, tipos
 * - Relaciones: consultas que unen customer, invoice, transaction, platform
 */
require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const app = express();
app.use(express.json());

// Pool MySQL con promesas
const pool = mysql.createPool({
  host: process.env.MYSQL_HOST,
  port: process.env.MYSQL_PORT,
  user: process.env.MYSQL_USER,
  password: process.env.MYSQL_PASSWORD,
  database: process.env.MYSQL_DATABASE,
  connectionLimit: 10
});

// ---- Helpers de validación ----
const isEmail = (s) => typeof s === 'string' && s.includes('@');
const isNumericLike = (v) => String(v).match(/^\d+$/);

// ---- Healthcheck ----
app.get('/api/health', async (req, res) => {
  try { await pool.query('SELECT 1'); res.json({ ok: true }); }
  catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

// ---- CRUD: CUSTOMER ----
app.get('/api/customers', async (req, res) => {
  const { q } = req.query;
  let sql = 'SELECT * FROM `customer` ORDER BY `customer_id`';
  let params = [];
  if (q) {
    sql = `SELECT * FROM \`customer\`
           WHERE CAST(\`national_id\` AS CHAR) LIKE ?
              OR \`full_name\` LIKE ?
              OR \`email\` LIKE ?
           ORDER BY \`customer_id\``;
    const like = `%${q}%`;
    params = [like, like, like];
  }
  const [rows] = await pool.query(sql, params);
  res.json(rows);
});

app.get('/api/customers/:id', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const [rows] = await pool.query('SELECT * FROM `customer` WHERE `customer_id`=?', [id]);
  if (!rows.length) return res.status(404).json({ error: 'Not found' });
  res.json(rows[0]);
});

app.post('/api/customers', async (req, res) => {
  const { national_id, full_name, address, phone, email } = req.body || {};
  if (!national_id || !isNumericLike(national_id)) return res.status(400).json({ error: 'national_id (numérico) es requerido' });
  if (!full_name) return res.status(400).json({ error: 'full_name es requerido' });
  if (email && !isEmail(email)) return res.status(400).json({ error: 'email inválido' });
  try {
    const [r] = await pool.query(
      `INSERT INTO \`customer\`(\`national_id\`, \`full_name\`, \`address\`, \`phone\`, \`email\`)
       VALUES(?,?,?,?,?)`,
      [national_id, full_name, address||null, phone||null, email||null]
    );
    const [rows] = await pool.query('SELECT * FROM `customer` WHERE `customer_id`=?', [r.insertId]);
    res.status(201).json(rows[0]);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.put('/api/customers/:id', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const { national_id, full_name, address, phone, email } = req.body || {};
  if (national_id != null && !isNumericLike(national_id)) return res.status(400).json({ error: 'national_id debe ser numérico' });
  if (email != null && email !== '' && !isEmail(email)) return res.status(400).json({ error: 'email inválido' });
  const [existing] = await pool.query('SELECT * FROM `customer` WHERE `customer_id`=?', [id]);
  if (!existing.length) return res.status(404).json({ error: 'Not found' });
  const row = existing[0];
  await pool.query(
    `UPDATE \`customer\` SET
      \`national_id\` = ?,
      \`full_name\`   = ?,
      \`address\`     = ?,
      \`phone\`       = ?,
      \`email\`       = ?
     WHERE \`customer_id\` = ?`,
    [
      national_id ?? row.national_id,
      full_name   ?? row.full_name,
      address     ?? row.address,
      phone       ?? row.phone,
      email       ?? row.email,
      id
    ]
  );
  const [rows] = await pool.query('SELECT * FROM `customer` WHERE `customer_id`=?', [id]);
  res.json(rows[0]);
});

app.delete('/api/customers/:id', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const [r] = await pool.query('DELETE FROM `customer` WHERE `customer_id`=?', [id]);
  res.json({ deleted: r.affectedRows });
});

app.use('/', express.static('../frontend'));

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`MySQL API running on http://localhost:${PORT}`));


// ---- Helpers de existencia (FK) ----
async function existsById(table, idCol, id) {
  const [rows] = await pool.query(`SELECT 1 FROM \`${table}\` WHERE \`${idCol}\` = ? LIMIT 1`, [id]);
  return rows.length > 0;
}

// ---- CRUD: INVOICE ----
app.get('/api/invoices', async (req, res) => {
  const { q, customer_id } = req.query;
  let sql = 'SELECT * FROM `invoice`';
  const params = [];
  const where = [];
  if (q) { where.push('`invoice_number` LIKE ?'); params.push(`%${q}%`); }
  if (customer_id) { where.push('`customer_id` = ?'); params.push(customer_id); }
  if (where.length) sql += ' WHERE ' + where.join(' AND ');
  sql += ' ORDER BY `invoice_id`';
  const [rows] = await pool.query(sql, params);
  res.json(rows);
});

app.get('/api/invoices/:id', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const [rows] = await pool.query('SELECT * FROM `invoice` WHERE `invoice_id`=?', [id]);
  if (!rows.length) return res.status(404).json({ error: 'Not found' });
  res.json(rows[0]);
});

app.post('/api/invoices', async (req, res) => {
  const { invoice_number, billing_period, amount_billed, customer_id } = req.body || {};
  if (!invoice_number) return res.status(400).json({ error: 'invoice_number es requerido' });
  if (!billing_period) return res.status(400).json({ error: 'billing_period es requerido' });
  const amt = Number(amount_billed);
  if (!(amt >= 0)) return res.status(400).json({ error: 'amount_billed debe ser >= 0' });
  if (!customer_id || !(await existsById('customer', 'customer_id', customer_id))) {
    return res.status(400).json({ error: 'customer_id es requerido y debe existir' });
  }
  try {
    const [r] = await pool.query(
      'INSERT INTO `invoice`(`invoice_number`,`billing_period`,`amount_billed`,`customer_id`) VALUES(?,?,?,?)',
      [invoice_number, billing_period, amt, customer_id]
    );
    const [rows] = await pool.query('SELECT * FROM `invoice` WHERE `invoice_id`=?', [r.insertId]);
    res.status(201).json(rows[0]);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.put('/api/invoices/:id', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const [existing] = await pool.query('SELECT * FROM `invoice` WHERE `invoice_id`=?', [id]);
  if (!existing.length) return res.status(404).json({ error: 'Not found' });
  const row = existing[0];
  const { invoice_number, billing_period, amount_billed, customer_id } = req.body || {};
  const amt = (amount_billed == null) ? row.amount_billed : Number(amount_billed);
  if (!(amt >= 0)) return res.status(400).json({ error: 'amount_billed debe ser >= 0' });
  if (customer_id != null && !(await existsById('customer', 'customer_id', customer_id))) {
    return res.status(400).json({ error: 'customer_id debe existir' });
  }
  try {
    await pool.query(
      `UPDATE \`invoice\` SET
        \`invoice_number\` = ?,
        \`billing_period\` = ?,
        \`amount_billed\`  = ?,
        \`customer_id\`    = ?
       WHERE \`invoice_id\` = ?`,
      [
        invoice_number ?? row.invoice_number,
        billing_period ?? row.billing_period,
        amt,
        customer_id ?? row.customer_id,
        id
      ]
    );
    const [rows] = await pool.query('SELECT * FROM `invoice` WHERE `invoice_id`=?', [id]);
    res.json(rows[0]);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.delete('/api/invoices/:id', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  try {
    const [r] = await pool.query('DELETE FROM `invoice` WHERE `invoice_id`=?', [id]);
    res.json({ deleted: r.affectedRows });
  } catch (e) {
    // Posible FK restrict por transacciones
    res.status(400).json({ error: e.message });
  }
});

// ---- CRUD: TRANSACTION ----
app.get('/api/transactions', async (req, res) => {
  const { platform, customer_id, invoice_id, status } = req.query;
  let sql = `SELECT t.*, p.name AS platform_name, c.full_name AS customer_name, i.invoice_number
             FROM \`transaction\` t
             JOIN \`platform\` p ON p.platform_id = t.platform_id
             JOIN \`customer\` c ON c.customer_id = t.customer_id
             JOIN \`invoice\`  i ON i.invoice_id = t.invoice_id`;
  const params = [];
  const where = [];
  if (platform) { where.push('LOWER(p.name) = LOWER(?)'); params.push(platform); }
  if (customer_id) { where.push('t.customer_id = ?'); params.push(customer_id); }
  if (invoice_id) { where.push('t.invoice_id = ?'); params.push(invoice_id); }
  if (status) { where.push('LOWER(t.status) = LOWER(?)'); params.push(status); }
  if (where.length) sql += ' WHERE ' + where.join(' AND ');
  sql += ' ORDER BY t.occurred_at DESC, t.transaction_id DESC';
  const [rows] = await pool.query(sql, params);
  res.json(rows);
});

app.get('/api/transactions/:id', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const [rows] = await pool.query('SELECT * FROM `transaction` WHERE `transaction_id`=?', [id]);
  if (!rows.length) return res.status(404).json({ error: 'Not found' });
  res.json(rows[0]);
});

app.post('/api/transactions', async (req, res) => {
  const { transaction_code, occurred_at, amount, status, type, platform_id, invoice_id, customer_id } = req.body || {};
  if (!transaction_code) return res.status(400).json({ error: 'transaction_code es requerido' });
  if (!occurred_at) return res.status(400).json({ error: 'occurred_at es requerido (YYYY-MM-DD HH:MM:SS)' });
  const amt = Number(amount);
  if (!(amt >= 0)) return res.status(400).json({ error: 'amount debe ser >= 0' });
  if (!status) return res.status(400).json({ error: 'status es requerido' });
  if (!type) return res.status(400).json({ error: 'type es requerido' });
  if (!platform_id || !(await existsById('platform', 'platform_id', platform_id))) return res.status(400).json({ error: 'platform_id inválido' });
  if (!invoice_id || !(await existsById('invoice', 'invoice_id', invoice_id))) return res.status(400).json({ error: 'invoice_id inválido' });
  if (!customer_id || !(await existsById('customer', 'customer_id', customer_id))) return res.status(400).json({ error: 'customer_id inválido' });

  try {
    const [r] = await pool.query(
      `INSERT INTO \`transaction\`(\`transaction_code\`, \`occurred_at\`, \`amount\`, \`status\`, \`type\`, \`platform_id\`, \`invoice_id\`, \`customer_id\`)
       VALUES(?,?,?,?,?,?,?,?)`,
      [transaction_code, occurred_at, amt, status, type, platform_id, invoice_id, customer_id]
    );
    const [rows] = await pool.query('SELECT * FROM `transaction` WHERE `transaction_id`=?', [r.insertId]);
    res.status(201).json(rows[0]);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.put('/api/transactions/:id', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const [existing] = await pool.query('SELECT * FROM `transaction` WHERE `transaction_id`=?', [id]);
  if (!existing.length) return res.status(404).json({ error: 'Not found' });
  const row = existing[0];
  const { transaction_code, occurred_at, amount, status, type, platform_id, invoice_id, customer_id } = req.body || {};
  const amt = (amount == null) ? row.amount : Number(amount);
  if (!(amt >= 0)) return res.status(400).json({ error: 'amount debe ser >= 0' });
  if (platform_id != null && !(await existsById('platform', 'platform_id', platform_id))) return res.status(400).json({ error: 'platform_id inválido' });
  if (invoice_id  != null && !(await existsById('invoice', 'invoice_id', invoice_id)))   return res.status(400).json({ error: 'invoice_id inválido' });
  if (customer_id != null && !(await existsById('customer', 'customer_id', customer_id))) return res.status(400).json({ error: 'customer_id inválido' });

  try {
    await pool.query(
      `UPDATE \`transaction\` SET
        \`transaction_code\` = ?,
        \`occurred_at\`      = ?,
        \`amount\`           = ?,
        \`status\`           = ?,
        \`type\`             = ?,
        \`platform_id\`      = ?,
        \`invoice_id\`       = ?,
        \`customer_id\`      = ?
       WHERE \`transaction_id\` = ?`,
      [
        transaction_code ?? row.transaction_code,
        occurred_at      ?? row.occurred_at,
        amt,
        status           ?? row.status,
        type             ?? row.type,
        platform_id      ?? row.platform_id,
        invoice_id       ?? row.invoice_id,
        customer_id      ?? row.customer_id,
        id
      ]
    );
    const [rows] = await pool.query('SELECT * FROM `transaction` WHERE `transaction_id`=?', [id]);
    res.json(rows[0]);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.delete('/api/transactions/:id', async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const [r] = await pool.query('DELETE FROM `transaction` WHERE `transaction_id`=?', [id]);
  res.json({ deleted: r.affectedRows });
});
