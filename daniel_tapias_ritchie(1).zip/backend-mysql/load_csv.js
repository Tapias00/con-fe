
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { parse } = require('csv-parse/sync');
const mysql = require('mysql2/promise');

async function main() {
  const pool = await mysql.createPool({
    host: process.env.MYSQL_HOST,
    port: process.env.MYSQL_PORT,
    user: process.env.MYSQL_USER,
    password: process.env.MYSQL_PASSWORD,
    database: process.env.MYSQL_DATABASE,
    connectionLimit: 10
  });
  const dataDir = path.resolve(__dirname, '../data');
  const run = (sql, params=[]) => pool.query(sql, params);

  try {
    console.log('Loading platforms...');
    const platforms = parse(fs.readFileSync(path.join(dataDir, 'platforms.csv')), {columns:true, skip_empty_lines:true});
    for (const r of platforms) {
      await run(
        "INSERT INTO `platform`(`platform_id`,`name`) VALUES(?,?) ON DUPLICATE KEY UPDATE `name`=VALUES(`name`)",
        [r.platform_id, r.platform_name || r.name || r.platform || r['platform_name'] || r['name']]
      );
    }

    console.log('Loading customers...');
    const customers = parse(fs.readFileSync(path.join(dataDir, 'customers.csv')), {columns:true, skip_empty_lines:true});
    for (const r of customers) {
      await run(
        "INSERT INTO `customer`(`customer_id`,`national_id`,`full_name`,`address`,`phone`,`email`) VALUES(?,?,?,?,?,?) "
        + "ON DUPLICATE KEY UPDATE `national_id`=VALUES(`national_id`), `full_name`=VALUES(`full_name`), `address`=VALUES(`address`), `phone`=VALUES(`phone`), `email`=VALUES(`email`)",
        [r.customer_id, r.customer_national_id || r.national_id, r.customer_name || r.full_name,
         r.customer_address || null, r.customer_phone || null, r.customer_email || null]
      );
    }

    console.log('Loading invoices...');
    const invoices = parse(fs.readFileSync(path.join(dataDir, 'invoices.csv')), {columns:true, skip_empty_lines:true});
    for (const r of invoices) {
      await run(
        "INSERT INTO `invoice`(`invoice_id`,`invoice_number`,`billing_period`,`amount_billed`,`customer_id`) VALUES(?,?,?,?,?) "
        + "ON DUPLICATE KEY UPDATE `billing_period`=VALUES(`billing_period`), `amount_billed`=VALUES(`amount_billed`), `customer_id`=VALUES(`customer_id`)",
        [r.invoice_id, r.invoice_number, r.billing_period, r.invoiced_amount, r.customer_id]
      );
    }

    console.log('Loading transactions...');
    const txs = parse(fs.readFileSync(path.join(dataDir, 'transactions.csv')), {columns:true, skip_empty_lines:true});
    for (const r of txs) {
      const dt = String(r.transaction_datetime).replace('T',' ').split('.')[0];
      await run(
        "INSERT INTO `transaction`(`transaction_id`,`transaction_code`,`occurred_at`,`amount`,`status`,`type`,`platform_id`,`invoice_id`,`customer_id`) VALUES(?,?,?,?,?,?,?,?,?) "
        + "ON DUPLICATE KEY UPDATE `transaction_code`=VALUES(`transaction_code`), `occurred_at`=VALUES(`occurred_at`), `amount`=VALUES(`amount`), `status`=VALUES(`status`), `type`=VALUES(`type`), `platform_id`=VALUES(`platform_id`), `invoice_id`=VALUES(`invoice_id`), `customer_id`=VALUES(`customer_id`)",
        [r.transaction_id, r.transaction_code, dt, r.transaction_amount, r.transaction_status, r.transaction_type,
         r.platform_id, r.invoice_id, r.customer_id]
      );
    }

    console.log('All data loaded to MySQL.');
    process.exit(0);
  } catch (e) {
    console.error('Error:', e);
    process.exit(1);
  }
}

main();
